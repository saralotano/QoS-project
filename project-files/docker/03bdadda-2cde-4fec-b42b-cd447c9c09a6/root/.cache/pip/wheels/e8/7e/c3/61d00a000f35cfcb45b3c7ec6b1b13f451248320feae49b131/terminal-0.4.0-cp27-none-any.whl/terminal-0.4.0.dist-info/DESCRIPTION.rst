    A terminal environment tools.

    :copyright: (c) 2013 by Hsiaoming Yang.

Home-page: https://github.com/lepture/terminal
Author: Hsiaoming Yang
Author-email: me@lepture.com
License: BSD
Description: Terminal: for Simple and Beautiful
        ==================================
        
        .. image:: https://travis-ci.org/lepture/terminal.png?branch=master
                :target: https://travis-ci.org/lepture/terminal
        .. image:: https://coveralls.io/repos/lepture/terminal/badge.png?branch=master
                :target: https://coveralls.io/r/lepture/terminal
        
        A better terminal tools for python.
        
        Find documentation at `Read The Docs`_.
        
        .. _`Read The Docs`: https://terminal.readthedocs.org/
        
        
        Features
        --------
        
        * An easy to use command parser
        * Full featured ANSI colors and styles
        * Full featured prompt communication
        * Nested and verbose logging
        * No dependencies (windows need colorama)
        
        Installation
        ------------
        
        To install terminal, simply::
        
            $ pip install terminal
        
        
        Contribute
        ----------
        
        Read the `Contribution Guide`_.
        
        .. _`Contribution Guide`: https://github.com/lepture/terminal/blob/master/CONTRIBUTING.rst
        
Platform: UNKNOWN
Classifier: Development Status :: 4 - Beta
Classifier: Environment :: Console
Classifier: Intended Audience :: Developers
Classifier: License :: OSI Approved
Classifier: License :: OSI Approved :: BSD License
Classifier: Operating System :: MacOS
Classifier: Operating System :: POSIX
Classifier: Operating System :: POSIX :: Linux
Classifier: Programming Language :: Python
Classifier: Programming Language :: Python :: 2.6
Classifier: Programming Language :: Python :: 2.7
Classifier: Programming Language :: Python :: 3.2
Classifier: Programming Language :: Python :: Implementation
Classifier: Programming Language :: Python :: Implementation :: CPython
Classifier: Programming Language :: Python :: Implementation :: PyPy
