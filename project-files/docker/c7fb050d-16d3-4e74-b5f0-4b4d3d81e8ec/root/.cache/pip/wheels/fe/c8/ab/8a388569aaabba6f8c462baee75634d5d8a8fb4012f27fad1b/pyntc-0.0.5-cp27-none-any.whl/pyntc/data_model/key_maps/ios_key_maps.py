# Key maps for IOS devices are stored here.

BASIC_FACTS_KM = {
    'model': 'hardware',
    'os_version': 'version',
    'serial_number': 'serial',
    'hostname': 'hostname',
}