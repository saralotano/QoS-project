
class CommandExecutionException(Exception):
    pass


class FailedCommit(Exception):
    pass


class ForcedCommit(Exception):
    pass
