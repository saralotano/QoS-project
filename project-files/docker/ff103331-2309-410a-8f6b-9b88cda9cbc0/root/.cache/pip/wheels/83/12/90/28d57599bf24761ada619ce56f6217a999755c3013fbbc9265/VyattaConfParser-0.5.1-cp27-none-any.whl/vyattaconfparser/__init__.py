from .parser import parse_conf

__title__ = 'Vyatta Config Parser'
__version__ = '0.5.1'
__author__ = 'Alexander Mironov'
__license__ = 'MIT'
__all__ = ['parse_conf']
