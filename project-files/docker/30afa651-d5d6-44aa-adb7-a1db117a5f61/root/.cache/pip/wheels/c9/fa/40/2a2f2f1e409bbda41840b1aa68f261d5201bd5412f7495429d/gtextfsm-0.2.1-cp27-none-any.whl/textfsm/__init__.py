from textfsm import *
__version__ = textfsm.__version__
